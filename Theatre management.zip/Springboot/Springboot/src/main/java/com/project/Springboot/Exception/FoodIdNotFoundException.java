package com.project.Springboot.Exception;

public class FoodIdNotFoundException extends RuntimeException  {
	String message = "Food Id Not Found";
	public String getMessage() {
		return message;
	}

}
