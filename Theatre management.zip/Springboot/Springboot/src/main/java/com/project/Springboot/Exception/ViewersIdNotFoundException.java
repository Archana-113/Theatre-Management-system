package com.project.Springboot.Exception;

public class ViewersIdNotFoundException extends RuntimeException{
	String message = "Viewers Id Not Found";
	public String getMessage() {
		return message;
	}

}
