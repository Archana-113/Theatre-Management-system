package com.project.Springboot.Exception;

public class StaffIdNotFoundException extends RuntimeException{
	String message = "Staff Id Not Found";
	public String getMessage() {
		return message;
	}

}
