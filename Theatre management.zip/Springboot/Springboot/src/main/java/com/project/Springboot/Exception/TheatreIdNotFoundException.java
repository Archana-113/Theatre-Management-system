package com.project.Springboot.Exception;

public class TheatreIdNotFoundException extends RuntimeException {
	String message = "Theatre Id Not Found";
	public String getMessage() {
		return message;
	}

}
