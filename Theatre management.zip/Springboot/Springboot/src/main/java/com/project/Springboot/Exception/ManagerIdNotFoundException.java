package com.project.Springboot.Exception;

public class ManagerIdNotFoundException extends RuntimeException {
	String message = "Manager Id Not Found";
	public String getMessage() {
		return message;
	}


}
