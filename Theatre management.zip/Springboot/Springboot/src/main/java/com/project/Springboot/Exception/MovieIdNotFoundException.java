package com.project.Springboot.Exception;

public class MovieIdNotFoundException extends RuntimeException{
	String message = "Movie Id Not Found";
	public String getMessage() {
		return message;
	}

}
