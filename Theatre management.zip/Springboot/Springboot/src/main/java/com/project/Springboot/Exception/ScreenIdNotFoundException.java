package com.project.Springboot.Exception;

public class ScreenIdNotFoundException extends RuntimeException{
	String message = "Screen Id Not Found";
	public String getMessage() {
		return message;
	}

}
