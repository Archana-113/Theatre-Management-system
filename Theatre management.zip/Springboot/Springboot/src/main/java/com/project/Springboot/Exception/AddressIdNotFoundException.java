package com.project.Springboot.Exception;


public class AddressIdNotFoundException extends RuntimeException{
	String message = "Address Id Not Found";
	public String getMessage() {
		return message;
	}

}
