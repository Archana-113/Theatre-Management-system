package com.project.Springboot.Exception;

public class SeatIdNotFoundException extends RuntimeException{
	String message = "Seat Id Not Found";
	public String getMessage() {
		return message;
	}

}
