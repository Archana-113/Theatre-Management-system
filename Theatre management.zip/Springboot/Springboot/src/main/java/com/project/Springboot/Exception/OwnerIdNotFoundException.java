package com.project.Springboot.Exception;

public class OwnerIdNotFoundException extends RuntimeException{
	String message = "Owner Id Not Found";
	public String getMessage() {
		return message;
	}

}
