package com.project.Springboot.Exception;

public class PaymentIdNotFoundException extends RuntimeException {
	String message = "Payment Id Not Found";
	public String getMessage() {
		return message;
	}

}
