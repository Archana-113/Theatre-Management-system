package com.project.Springboot.Exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.project.Springboot.util.ResponseStructure;
@RestControllerAdvice
public class ApplicationExceptionHandler {
	
	@Autowired
	ResponseStructure<String> responseStructure;
	
	@ExceptionHandler(AddressIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> addressIdNotFound(AddressIdNotFoundException addressIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Address Id not present in DB");
		responseStructure.setData(addressIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(BranchIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> branchIdNotFound(BranchIdNotFoundException branchIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Branch Id not present in DB");
		responseStructure.setData(branchIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(FoodIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> foodIdNotFound(FoodIdNotFoundException foodIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Food Id not present in DB");
		responseStructure.setData(foodIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ManagerIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> managerIdNotFound(ManagerIdNotFoundException managerIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Manager Id not present in DB");
		responseStructure.setData(managerIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(MovieIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> movieIdNotFound(MovieIdNotFoundException movieIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Movie Id not present in DB");
		responseStructure.setData(movieIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(OwnerIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> ownerIdNotFound(OwnerIdNotFoundException ownerIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Owner Id not present in DB");
		responseStructure.setData(ownerIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(PaymentIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> paymentIdNotFound(PaymentIdNotFoundException paymentIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Payment Id not present in DB");
		responseStructure.setData(paymentIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ReviewIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> reviewIdNotFound(ReviewIdNotFoundException reviewIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Review Id not present in DB");
		responseStructure.setData(reviewIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ScreenIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> screenIdNotFound(ScreenIdNotFoundException screenIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Screen Id not present in DB");
		responseStructure.setData(screenIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(SeatIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> seatIdNotFound(SeatIdNotFoundException seatIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Seat Id not present in DB");
		responseStructure.setData(seatIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(StaffIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> staffIdNotFound(StaffIdNotFoundException staffIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Staff Id not present in DB");
		responseStructure.setData(staffIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(TheatreIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> theatreIdNotFound(TheatreIdNotFoundException theatreIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Theatre Id not present in DB");
		responseStructure.setData(theatreIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(TicketIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> ticketIdNotFound(TicketIdNotFoundException ticketIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Ticket Id not present in DB");
		responseStructure.setData(ticketIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ViewersIdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> viewersIdNotFound(ViewersIdNotFoundException viewersIdNotFoundException){
		responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
		responseStructure.setMessage("Viewers Id not present in DB");
		responseStructure.setData(viewersIdNotFoundException.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(responseStructure,HttpStatus.NOT_FOUND);
	}
	

}
