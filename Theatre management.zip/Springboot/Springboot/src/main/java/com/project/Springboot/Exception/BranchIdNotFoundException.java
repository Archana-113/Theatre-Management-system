package com.project.Springboot.Exception;


public class BranchIdNotFoundException extends RuntimeException {
	String message = "Branch Id Not Found";
	public String getMessage() {
		return message;
	}
	
	
}
