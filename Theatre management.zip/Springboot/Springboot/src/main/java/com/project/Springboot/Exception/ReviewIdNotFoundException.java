package com.project.Springboot.Exception;

public class ReviewIdNotFoundException extends RuntimeException{
	String message = "Review Id Not Found";
	public String getMessage() {
		return message;
	}

}
