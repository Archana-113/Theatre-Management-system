package com.project.Springboot.Exception;

public class TicketIdNotFoundException extends RuntimeException{
	String message = "Ticket Id Not Found";
	public String getMessage() {
		return message;
	}

}
