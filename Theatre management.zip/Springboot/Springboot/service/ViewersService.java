package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.ViewersIdNotFoundException;
import com.project.Springboot.dao.ViewersDao;
import com.project.Springboot.dto.Viewers;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class ViewersService {
	@Autowired
	ViewersDao viewersDao;
	
	@Autowired
	ResponseStructure<Viewers> responseStructure;
	
	@Autowired
	ResponseStructureList<Viewers> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Viewers>> saveViewers(Viewers viewers){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Viewers inserted into DB");
		responseStructure.setData(viewersDao.saveViewers(viewers));
		return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Viewers>> fetchViewersById(int viewersId ){
		Viewers viewers = viewersDao.fetchViewersById(viewersId);
		if(viewers!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully Viewers fetched from DB");
		responseStructure.setData(viewers);
		return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new ViewersIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Viewers>> fetchAllViewers(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all Viewers fetched from DB");
		responseStructureList.setData(viewersDao.fetchAllViewers());
		return new ResponseEntity<ResponseStructureList<Viewers>>(responseStructureList,HttpStatus.FOUND);
		
	}
	public ResponseEntity<ResponseStructure<Viewers>> updateViewersById(int oldViewersId ,Viewers newViewers){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Ticket updated in DB");
		responseStructure.setData(viewersDao.updateViewersById(oldViewersId, newViewers));
		return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Viewers>> deleteViewersById(int viewersId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Ticket deleted from DB");
		responseStructure.setData(viewersDao.deleteViewersById(viewersId));
		return new ResponseEntity<ResponseStructure<Viewers>>(responseStructure,HttpStatus.OK);
	}

}
