package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.TheatreIdNotFoundException;
import com.project.Springboot.dao.TheatreDao;
import com.project.Springboot.dto.Theatre;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class TheatreService {
	@Autowired
	TheatreDao theatreDao;
	
	@Autowired
	ResponseStructure<Theatre> responseStructure;
	
	@Autowired
	ResponseStructureList<Theatre> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Theatre>> saveTheatre(Theatre theatre){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Theatre inserted into DB");
		responseStructure.setData(theatreDao.saveTheatre(theatre));
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Theatre>> fetchTheatreById(int theatreId ){
		Theatre theatre = theatreDao.fetchTheatreById(theatreId);
		if(theatre!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully theatre fetched from DB");
		responseStructure.setData(theatre);
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new TheatreIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Theatre>> fetchAllTheatre(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all Theatre fetched from DB");
		responseStructureList.setData(theatreDao.fetchAllTheatre());
		return new ResponseEntity<ResponseStructureList<Theatre>>(responseStructureList,HttpStatus.FOUND);
		
	}
	public ResponseEntity<ResponseStructure<Theatre>> updateTheatreById(int oldTheatreId ,Theatre newTheatre){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Theatre updated in DB");
		responseStructure.setData(theatreDao.updateTheatreById(oldTheatreId, newTheatre));
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Theatre>> deleteTheatreById(int theatreId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Theatre deleted from DB");
		responseStructure.setData(theatreDao.deleteTheatreById(theatreId));
		return new ResponseEntity<ResponseStructure<Theatre>>(responseStructure,HttpStatus.OK);
	}

}
