package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.MovieIdNotFoundException;
import com.project.Springboot.dao.MovieDao;
import com.project.Springboot.dto.Movie;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class MovieService {
	@Autowired
	MovieDao movieDao;
	
	@Autowired
	ResponseStructure<Movie> responseStructure;
	
	@Autowired
	ResponseStructureList<Movie> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Movie>> saveMovie(Movie movie){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully movie inserted into DB");
		responseStructure.setData(movieDao.saveMovie(movie));
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Movie>> fetchMovieById(int movieId){
		Movie movie = movieDao.fetchMovieById(movieId);
		if(movie!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully movie fetched from DB");
		responseStructure.setData(movie);
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new MovieIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Movie>> fetchAllMovie(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all movies fetched from DB");
		responseStructureList.setData(movieDao.fetchAllMovie());
		return new ResponseEntity<ResponseStructureList<Movie>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Movie>> updateMovieById(int oldMovieId,Movie newMovie){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully movie updated in DB");
		responseStructure.setData(movieDao.updateMovieById(oldMovieId,newMovie));
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Movie>> deleteMovieById(int movieId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully movie delete from DB");
		responseStructure.setData(movieDao.deleteMovieById(movieId));
		return new ResponseEntity<ResponseStructure<Movie>>(responseStructure,HttpStatus.OK);
	}

}
