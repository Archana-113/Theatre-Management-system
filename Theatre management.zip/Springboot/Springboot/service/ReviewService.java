package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.ReviewIdNotFoundException;
import com.project.Springboot.dao.ReviewDao;
import com.project.Springboot.dto.Review;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class ReviewService {
	@Autowired
	ReviewDao reviewDao;
	
	@Autowired
	ResponseStructure<Review> responseStructure;
	
	@Autowired
	ResponseStructureList<Review> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Review>> saveReview(Review review){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Review inserted into DB");
		responseStructure.setData(reviewDao.saveReview(review));
		return new ResponseEntity<ResponseStructure<Review>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Review>> fetchReviewById(int reviewId){
		Review review = reviewDao.fetchReviewById(reviewId);
		if(review!=null) {
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Review fetched from DB");
			responseStructure.setData(review);
			return new ResponseEntity<ResponseStructure<Review>>(responseStructure,HttpStatus.FOUND);	
		}else {
			throw new ReviewIdNotFoundException();
		}		
	}
	public ResponseEntity<ResponseStructureList<Review>> fetchAllReview(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully All Reviewes fetched from DB");
		responseStructureList.setData(reviewDao.fetchAllReview());
		return new ResponseEntity<ResponseStructureList<Review>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Review>> updateReviewById(int oldReviewId,Review newReview){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Review updated in DB");
		responseStructure.setData(reviewDao.updateReviewById(oldReviewId,newReview));
		return new ResponseEntity<ResponseStructure<Review>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Review>> deleteReviewById(int reviewId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Review deleted from DB");
		responseStructure.setData(reviewDao.deleteReviewById(reviewId));
		return new ResponseEntity<ResponseStructure<Review>>(responseStructure,HttpStatus.OK);
	}
	

}
