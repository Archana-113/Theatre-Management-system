package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.OwnerIdNotFoundException;
import com.project.Springboot.dao.OwnerDao;
import com.project.Springboot.dto.Owner;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class OwnerService {
	@Autowired
	OwnerDao ownerDao;
	
	@Autowired
	ResponseStructure<Owner> responseStructure;
	
	@Autowired
	ResponseStructureList<Owner> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Owner>> saveOwner(Owner owner){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully owner inserted into DB");
		responseStructure.setData(ownerDao.saveOwner(owner));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Owner>> fetchOwnerById(int ownerId){
		Owner owner = ownerDao.fetchOwnerById(ownerId);
		if(owner!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully owner fetched from DB");
		responseStructure.setData(ownerDao.saveOwner(owner));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new OwnerIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Owner>> fetchAllOwner(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all owners fetched from DB");
		responseStructureList.setData(ownerDao.fetchAllOwner());
		return new ResponseEntity<ResponseStructureList<Owner>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Owner>> updateOwnerById(int oldOwnerId ,Owner newOwner){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully owner updated in DB");
		responseStructure.setData(ownerDao.updateOwnerById(oldOwnerId, newOwner));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.OK);
		
	}
	public ResponseEntity<ResponseStructure<Owner>> deleteOwnerById(int ownerId ){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully owner deleted from DB");
		responseStructure.setData(ownerDao.deleteOwnerById(ownerId));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.OK);		
	}
}
