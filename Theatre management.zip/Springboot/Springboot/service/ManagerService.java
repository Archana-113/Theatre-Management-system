package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.ManagerIdNotFoundException;
import com.project.Springboot.dao.ManagerDao;
import com.project.Springboot.dto.Food;
import com.project.Springboot.dto.Manager;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class ManagerService {
	@Autowired
	ManagerDao managerDao;
	
	@Autowired
	ResponseStructure<Manager> responseStructure;
	
	@Autowired
	ResponseStructureList<Manager> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Manager>> saveManager(Manager manager){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully manager inserted into DB");
		responseStructure.setData(managerDao.saveManager(manager));
		return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Manager>> fetchManagerById(int managerId){
		Manager manager = managerDao.fetchManagerById(managerId);
		if(manager!=null) {
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully manager fetched from DB");
			responseStructure.setData(manager);
			return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new ManagerIdNotFoundException();
		}	
	}
	public ResponseEntity<ResponseStructureList<Manager>> fetchAllManager(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully All manager fetched from DB");
		responseStructureList.setData(managerDao.fetchAllManager());
		return new ResponseEntity<ResponseStructureList<Manager>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Manager>> updateMangerById(int oldManagerId,Manager newManager){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully manager inserted into DB");
		responseStructure.setData(managerDao.updateManagerById(oldManagerId,newManager));
		return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Manager>> deleteMangerById(int managerId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully manager inserted into DB");
		responseStructure.setData(managerDao.deleteManagerById(managerId));
		return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.OK);
	}

}
