package com.project.Springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.AddressIdNotFoundException;
import com.project.Springboot.dao.AddressDao;
import com.project.Springboot.dto.Address;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class AddressService {
	@Autowired
	AddressDao addressDao;
	
	@Autowired
	ResponseStructure<Address> responseStructure;
	
	@Autowired
	ResponseStructureList<Address> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Address>> saveAddress(Address address) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Address inserted into DB");
		responseStructure.setData(addressDao.saveAddress(address));
		return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Address>> fetchAddressById(int addressId) {
		Address address = addressDao.fetchAddressById(addressId);
		if(address != null) {
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully address fetched from the DB");
			responseStructure.setData(addressDao.fetchAddressById(addressId));
			return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.FOUND);
			
		}else {
			throw new AddressIdNotFoundException();
		}
		
	}
	public ResponseEntity<ResponseStructure<Address>> updateAddressById(int oldAddress,Address newAddress) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully address Updated in the DB");
		responseStructure.setData(addressDao.updateAddressById(oldAddress, newAddress));
		return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.OK);
		
	}
	public ResponseEntity<ResponseStructureList<Address>> fetchAllAddress(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all addresses fetched from the DB");
		responseStructureList.setData(addressDao.findAllAddress());
		return new ResponseEntity<ResponseStructureList<Address>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Address>> deleteAddressById(int addressId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully address Deleted from the DB");
		responseStructure.setData(addressDao.deleteAddressById(addressId));
		return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.OK);
		
	}
}