package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.FoodIdNotFoundException;
import com.project.Springboot.dao.FoodDao;
import com.project.Springboot.dto.Food;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.servers.Server;

@Service
public class FoodService {
	@Autowired
	FoodDao foodDao;
	
	@Autowired
	ResponseStructure<Food> responseStructure;
	
	@Autowired
	ResponseStructureList<Food> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Food>> saveFood(Food food){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully food inserted into DB");
		responseStructure.setData(foodDao.saveFood(food));
		return new ResponseEntity<ResponseStructure<Food>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Food>> fetchFoodById(int foodId){
		Food food = foodDao.fetchFoodById(foodId);
		if(food!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully food fetched from DB");
		responseStructure.setData(food);
		return new ResponseEntity<ResponseStructure<Food>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new FoodIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Food>> fetchAllFood(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully All food fetched from DB");
		responseStructureList.setData(foodDao.fetchAllFood());
		return new ResponseEntity<ResponseStructureList<Food>>(responseStructureList,HttpStatus.FOUND);	
	}
	public ResponseEntity<ResponseStructure<Food>> updateFoodById(int foodId,Food newFood){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully food updated in DB");
		responseStructure.setData(foodDao.updateFoodById(foodId,newFood ));
		return new ResponseEntity<ResponseStructure<Food>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Food>> deleteFoodById(int foodId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully food deleted from DB");
		responseStructure.setData(foodDao.deleteFoodById(foodId));
		return new ResponseEntity<ResponseStructure<Food>>(responseStructure,HttpStatus.OK);
	}
}
