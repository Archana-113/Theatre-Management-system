
package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.BranchIdNotFoundException;
import com.project.Springboot.dao.BranchDao;
import com.project.Springboot.dto.Branch;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class BranchService {
	@Autowired
	BranchDao branchDao;
	
	@Autowired
	ResponseStructure<Branch> responseStructure;
	
	@Autowired
	ResponseStructureList<Branch> responseStructureList;

	public ResponseEntity<ResponseStructure<Branch>> saveBranch(Branch branch){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Branch inserted into DB");
		responseStructure.setData(branchDao.saveBranch(branch));
		return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.CREATED);	
	}
	public ResponseEntity<ResponseStructure<Branch>> fetchBranchById(int branchId){
		Branch branch = branchDao.fetchBranchById(branchId);
		if(branch!=null) {
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully Branch fetch from DB");
			responseStructure.setData(branch);
			return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.FOUND);	
		}else {
			throw new BranchIdNotFoundException();
		}	
	}
	public ResponseEntity<ResponseStructureList<Branch>> fetchAllBranch(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully All Branches fetched from DB");
		responseStructureList.setData(branchDao.fetchAllBranch());
		return new ResponseEntity<ResponseStructureList<Branch>>(responseStructureList,HttpStatus.FOUND); 
	}
	public ResponseEntity<ResponseStructure<Branch>> updateBranchById(int oldBranchId,Branch newBranch){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Branch Updated in DB");
		responseStructure.setData(branchDao.updateBranchById(oldBranchId,newBranch));
		return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.OK);	
	}
	public ResponseEntity<ResponseStructure<Branch>> deleteBranchById(int branchId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Branch deleted from DB");
		responseStructure.setData(branchDao.deleteBranchById(branchId));
		return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.OK);	
	}
	
}
