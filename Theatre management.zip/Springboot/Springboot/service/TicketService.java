package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.TicketIdNotFoundException;
import com.project.Springboot.dao.TicketDao;
import com.project.Springboot.dto.Ticket;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class TicketService {
	@Autowired
	TicketDao ticketDao;
	
	@Autowired
	ResponseStructure<Ticket> responseStructure;
	
	@Autowired
	ResponseStructureList<Ticket> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Ticket>> saveTicket(Ticket ticket){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Ticket inserted into DB");
		responseStructure.setData(ticketDao.saveTicket(ticket));
		return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Ticket>> fetchTicketById(int ticketId ){
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		if(ticket!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully Ticket fetched from DB");
		responseStructure.setData(ticket);
		return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new TicketIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Ticket>> fetchAllTicket(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all Ticket fetched from DB");
		responseStructureList.setData(ticketDao.fetchAllTicket());
		return new ResponseEntity<ResponseStructureList<Ticket>>(responseStructureList,HttpStatus.FOUND);
		
	}
	public ResponseEntity<ResponseStructure<Ticket>> updateTicketById(int oldTicketId ,Ticket newTicket){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Ticket updated in DB");
		responseStructure.setData(ticketDao.updateTicketById(oldTicketId, newTicket));
		return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Ticket>> deleteTicketById(int ticketId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Ticket deleted from DB");
		responseStructure.setData(ticketDao.deleteTicketById(ticketId));
		return new ResponseEntity<ResponseStructure<Ticket>>(responseStructure,HttpStatus.OK);
	}
	

}
