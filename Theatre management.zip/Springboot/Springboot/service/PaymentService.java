package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.PaymentIdNotFoundException;
import com.project.Springboot.dao.PaymentDao;
import com.project.Springboot.dto.Payment;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class PaymentService {
	@Autowired
	PaymentDao paymentDao;
	
	@Autowired
	ResponseStructure<Payment> responseStructure;
	
	@Autowired
	ResponseStructureList<Payment> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Payment>> savePayment(Payment payment){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Payment inserted into DB");
		responseStructure.setData(paymentDao.savePayment(payment));
		return new ResponseEntity<ResponseStructure<Payment>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Payment>> fetchPaymentById(int paymentId){
		Payment payment = paymentDao.fetchPaymentById(paymentId);
		if(payment!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully Payment fetched from DB");
		responseStructure.setData(payment);
		return new ResponseEntity<ResponseStructure<Payment>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new PaymentIdNotFoundException();
		}		
	}
	public ResponseEntity<ResponseStructureList<Payment>> fetchAllPayment(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully All Payment fetched from DB");
		responseStructureList.setData(paymentDao.fetchAllPayment());
		return new ResponseEntity<ResponseStructureList<Payment>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Payment>> updatePaymentById(int oldPaymentId,Payment newPayemnt){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Payment updated in DB");
		responseStructure.setData(paymentDao.updatePaymentById(oldPaymentId, newPayemnt));
		return new ResponseEntity<ResponseStructure<Payment>>(responseStructure,HttpStatus.OK);
	} 
	public ResponseEntity<ResponseStructure<Payment>> deletePaymentById(int paymentId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Payment deleted from DB");
		responseStructure.setData(paymentDao.deletePaymentById(paymentId));
		return new ResponseEntity<ResponseStructure<Payment>>(responseStructure,HttpStatus.OK);
	} 

}
