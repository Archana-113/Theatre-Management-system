package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.SeatIdNotFoundException;
import com.project.Springboot.dao.SeatDao;
import com.project.Springboot.dto.Seat;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class SeatService {
	@Autowired
	SeatDao seatDao;
	
	@Autowired
	ResponseStructure<Seat> responseStructure;
	
	@Autowired
	ResponseStructureList<Seat> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Seat>> saveSeat(Seat seat){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Seat inserted into DB");
		responseStructure.setData(seatDao.saveSeat(seat));
		return new ResponseEntity<ResponseStructure<Seat>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Seat>> fetchSeatById(int seatId){
		Seat seat = seatDao.fetchSeatById(seatId);
		if(seat!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully Seat fetched from DB");
		responseStructure.setData(seat);
		return new ResponseEntity<ResponseStructure<Seat>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new SeatIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<Seat>> fetchAllSeat(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully Seat fetched from DB");
		responseStructureList.setData(seatDao.fetchAllSeat());
		return new ResponseEntity<ResponseStructureList<Seat>>(responseStructureList,HttpStatus.FOUND);
		
	}
	public ResponseEntity<ResponseStructure<Seat>> updateSeatById(int oldSeatId,Seat newSeat){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Seat updated in DB");
		responseStructure.setData(seatDao.updateSeatById(oldSeatId, newSeat));
		return new ResponseEntity<ResponseStructure<Seat>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Seat>> deleteSeatById(int seatId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Seat deleted from DB");
		responseStructure.setData(seatDao.deleteSeatById(seatId));
		return new ResponseEntity<ResponseStructure<Seat>>(responseStructure,HttpStatus.OK );
	}

}
