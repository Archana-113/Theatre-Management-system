package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.ScreenIdNotFoundException;
import com.project.Springboot.dao.ScreenDao;
import com.project.Springboot.dto.Screen;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class ScreenService {
	@Autowired
	ScreenDao screenDao;
	
	@Autowired
	ResponseStructure<Screen> responseStructure;
	
	@Autowired
	ResponseStructureList<Screen> responseStructureList;
	
	public ResponseEntity<ResponseStructure<Screen>> saveScreen(Screen screen){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Screen inserted into DB");
		responseStructure.setData(screenDao.saveScreen(screen));
		return new ResponseEntity<ResponseStructure<Screen>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Screen>> fetchScreenById(int screenId){
		Screen screen = screenDao.fetchScreenById(screenId);
		if(screen!=null) {
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setMessage("Successfully screen fetched from DB");
			responseStructure.setData(screen);
			return new ResponseEntity<ResponseStructure<Screen>>(responseStructure,HttpStatus.FOUND);	
		}else {
			throw new ScreenIdNotFoundException();
		}		
	}
	public ResponseEntity<ResponseStructureList<Screen>> fetchAllScreen(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully All Screens fetched from DB");
		responseStructureList.setData(screenDao.fetchAllScreen());
		return new ResponseEntity<ResponseStructureList<Screen>>(responseStructureList,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Screen>> updateScreenById(int oldScreenId,Screen newScreen){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Screen updated in DB");
		responseStructure.setData(screenDao.updateScreenById(oldScreenId,newScreen));
		return new ResponseEntity<ResponseStructure<Screen>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<Screen>> deleteScreenById(int screenId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully Screen deleted from DB");
		responseStructure.setData(screenDao.deleteScreenById(screenId));
		return new ResponseEntity<ResponseStructure<Screen>>(responseStructure,HttpStatus.OK);
	}

}
