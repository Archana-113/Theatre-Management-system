package com.project.Springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.Springboot.Exception.StaffIdNotFoundException;
import com.project.Springboot.dao.StaffDao;
import com.project.Springboot.dto.Seat;
import com.project.Springboot.dto.staff;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@Service
public class StaffService {
	@Autowired
	StaffDao staffDao;
	
	@Autowired
	ResponseStructure<staff> responseStructure;
	
	@Autowired
	ResponseStructureList<staff> responseStructureList;
	
	public ResponseEntity<ResponseStructure<staff>> saveStaff(staff staffObj){
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Successfully Seat inserted into DB");
		responseStructure.setData(staffDao.saveStaff(staffObj));
		return new ResponseEntity<ResponseStructure<staff>>(responseStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<staff>> fetchStaffById(int staffId ){
		staff staffObj = staffDao.fetchStaffById(staffId);
		if(staffObj!=null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Successfully staff fetched from DB");
		responseStructure.setData(staffObj);
		return new ResponseEntity<ResponseStructure<staff>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new StaffIdNotFoundException();
		}
	}
	public ResponseEntity<ResponseStructureList<staff>> fetchAllStaff(){
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMessage("Successfully all staffs fetched from DB");
		responseStructureList.setData(staffDao.fetchAllStaff());
		return new ResponseEntity<ResponseStructureList<staff>>(responseStructureList,HttpStatus.FOUND);
		
	}
	public ResponseEntity<ResponseStructure<staff>> updateStaffById(int oldStaffId ,staff newStaff){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully staff updated in DB");
		responseStructure.setData(staffDao.updateStaffById(oldStaffId, newStaff));
		return new ResponseEntity<ResponseStructure<staff>>(responseStructure,HttpStatus.OK);
	}
	public ResponseEntity<ResponseStructure<staff>> deleteStaffById(int staffId){
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Successfully staff deleted from DB");
		responseStructure.setData(staffDao.deleteStaffById(staffId));
		return new ResponseEntity<ResponseStructure<staff>>(responseStructure,HttpStatus.OK);
	}
	

}
