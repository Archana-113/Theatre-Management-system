package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Screen;
import com.project.Springboot.service.ScreenService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class ScreenController {
	@Autowired
	ScreenService screenService;
	
	@Operation(summary = "Save Screen", description = "API is used to save the Screen")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveScreen")
	public ResponseEntity<ResponseStructure<Screen>> saveScreen(@RequestBody Screen screen) {
		return screenService.saveScreen(screen);	
	}
	@Operation(summary = "Fetch Screen By Id", description = "API is used to Fetch the Screen")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Screen fetched "),
			@ApiResponse(responseCode = "404", description = "Screen not found for the given id") })
	@GetMapping("/fetchScreenById")
	public ResponseEntity<ResponseStructure<Screen>> fetchScreenById(@RequestParam int screenId){
		return screenService.fetchScreenById(screenId);
	}
	@Operation(summary = "Fetch All Screens", description = "API is used to fetch all the Screens")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Screens fetched "),
			@ApiResponse(responseCode = "404", description = "no Screens found") })
	@GetMapping("/fetchAllScreen")
	public ResponseEntity<ResponseStructureList<Screen>> fetchAllScreen(){
		return screenService.fetchAllScreen();
	}
	@Operation(summary = "Update Screen", description = "API is used to update the Screen")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Screen Upadted "),
			@ApiResponse(responseCode = "404", description = "Screen not found for the given id") })
	@PutMapping("/updateScreenById")
	public ResponseEntity<ResponseStructure<Screen>> updateScreenById(@RequestParam int oldScreenId,@RequestBody Screen newScreen){
		return screenService.updateScreenById(oldScreenId, newScreen);
	}
	@Operation(summary = "Delete Screen", description = "API is used to delete the Screen")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Screen deleted "),
			@ApiResponse(responseCode = "404", description = "Screen not found for the given id") })
	@DeleteMapping("/deleteScreenById")
	public ResponseEntity<ResponseStructure<Screen>> deleteScreenById(@RequestParam int screenId){
		return screenService.deleteScreenById(screenId);
	}


}
