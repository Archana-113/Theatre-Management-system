package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Theatre;
import com.project.Springboot.service.TheatreService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class TheatreController {
	@Autowired
	TheatreService theatreService;
	
	@Operation(summary = "Save Theatre", description = "API is used to save the Theatre")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveTheatre")
	public ResponseEntity<ResponseStructure<Theatre>> saveTheatre(@RequestBody Theatre theatre) {
		return theatreService.saveTheatre(theatre);	
	}
	@Operation(summary = "Fetch Theatre By Id", description = "API is used to Fetch the Theatre")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Theatre fetched "),
			@ApiResponse(responseCode = "404", description = "Theatre not found for the given id") })
	@GetMapping("/fetchTheatreById")
	public ResponseEntity<ResponseStructure<Theatre>> fetchTheatreById(@RequestParam int theatreId){
		return theatreService.fetchTheatreById(theatreId);
	}
	@Operation(summary = "Fetch All Theatres", description = "API is used to fetch all the Theatres")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Theatres fetched "),
			@ApiResponse(responseCode = "404", description = "no Theatres found") })
	@GetMapping("/fetchAllTheatre")
	public ResponseEntity<ResponseStructureList<Theatre>> fetchAllTheatre(){
		return theatreService.fetchAllTheatre();
	}
	@Operation(summary = "Update Theatre", description = "API is used to update the Theatre")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Theatre Upadted "),
			@ApiResponse(responseCode = "404", description = "Theatre not found for the given id") })
	@PutMapping("/updateTheatreById")
	public ResponseEntity<ResponseStructure<Theatre>> updateTheatreById(@RequestParam int oldTheatreId,@RequestBody Theatre newTheatre){
		return theatreService.updateTheatreById(oldTheatreId, newTheatre);
	}
	@Operation(summary = "Delete Theatre", description = "API is used to delete the Theatre")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Theatre deleted "),
			@ApiResponse(responseCode = "404", description = "Theatre not found for the given id") })
	@DeleteMapping("/deleteTheatreById")
	public ResponseEntity<ResponseStructure<Theatre>> deleteTheatreById(@RequestParam int theatreId){
		return theatreService.deleteTheatreById(theatreId);
	}


}
