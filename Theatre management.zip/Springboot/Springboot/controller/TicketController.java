package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Ticket;
import com.project.Springboot.service.TicketService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class TicketController {
	@Autowired
	TicketService ticketService;
	
	@Operation(summary = "Save Ticket", description = "API is used to save the Ticket")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveTicket")
	public ResponseEntity<ResponseStructure<Ticket>> saveTicket(@RequestBody Ticket ticket) {
		return ticketService.saveTicket(ticket);	
	}
	@Operation(summary = "Fetch Ticket By Id", description = "API is used to Fetch the Ticket")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Ticket fetched "),
			@ApiResponse(responseCode = "404", description = "Ticket not found for the given id") })
	@GetMapping("/fetchTicketById")
	public ResponseEntity<ResponseStructure<Ticket>> fetchTicketById(@RequestParam int ticketId){
		return ticketService.fetchTicketById(ticketId);
	}
	@Operation(summary = "Fetch All Tickets", description = "API is used to fetch all the Tickets")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Tickets fetched "),
			@ApiResponse(responseCode = "404", description = "no Tickets found") })
	@GetMapping("/fetchAllTicket")
	public ResponseEntity<ResponseStructureList<Ticket>> fetchAllTicket(){
		return ticketService.fetchAllTicket();
	}
	@Operation(summary = "Update Ticket", description = "API is used to update the Ticket")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Ticket Upadted "),
			@ApiResponse(responseCode = "404", description = "Ticket not found for the given id") })
	@PutMapping("/updateTicketById")
	public ResponseEntity<ResponseStructure<Ticket>> updateTicketById(@RequestParam int oldTicketId,@RequestBody Ticket newTicket){
		return ticketService.updateTicketById(oldTicketId, newTicket);
	}
	@Operation(summary = "Delete Ticket", description = "API is used to delete the Ticket")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Ticket deleted "),
			@ApiResponse(responseCode = "404", description = "Ticket not found for the given id") })
	@DeleteMapping("/deleteTicketById")
	public ResponseEntity<ResponseStructure<Ticket>> deleteTicketById(@RequestParam int ticketId){
		return ticketService.deleteTicketById(ticketId);
	}

}
