package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Food;
import com.project.Springboot.service.FoodService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class FoodController {
	@Autowired
	FoodService foodService;
	
	@Operation(summary = "Save Food", description = "API is used to save the Food")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveFood")
	public ResponseEntity<ResponseStructure<Food>> saveFood(@RequestBody Food food) {
		return foodService.saveFood(food);	
	}
	@Operation(summary = "Fetch Food By Id", description = "API is used to Fetch the Food")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Food fetched "),
			@ApiResponse(responseCode = "404", description = "Food not found for the given id") })
	@GetMapping("/fetchFoodById")
	public ResponseEntity<ResponseStructure<Food>> fetchFoodById(@RequestParam int foodId){
		return foodService.fetchFoodById(foodId);
	}
	@Operation(summary = "Fetch All Foods", description = "API is used to fetch all the Foods")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Foods fetched "),
			@ApiResponse(responseCode = "404", description = "no Food found") })
	@GetMapping("/fetchAllFood")
	public ResponseEntity<ResponseStructureList<Food>> fetchAllFood(){
		return foodService.fetchAllFood();
	}
	@Operation(summary = "Update Food", description = "API is used to update the Food")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Food Upadted "),
			@ApiResponse(responseCode = "404", description = "Food not found for the given id") })
	@PutMapping("/updateFoodById")
	public ResponseEntity<ResponseStructure<Food>> updateFoodById(@RequestParam int oldFoodId,@RequestBody Food newFood){
		return foodService.updateFoodById(oldFoodId, newFood);
	}
	@Operation(summary = "Delete Food", description = "API is used to delete the Food")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Branch deleted "),
			@ApiResponse(responseCode = "404", description = "Food not found for the given id") })
	@DeleteMapping("/deleteFoodById")
	public ResponseEntity<ResponseStructure<Food>> deleteFoodById(@RequestParam int foodId){
		return foodService.deleteFoodById(foodId);
	}

}
