package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Payment;
import com.project.Springboot.service.PaymentService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController

public class PaymentController {
	@Autowired
	PaymentService paymentService;
	
	@Operation(summary = "Save Payment", description = "API is used to save the Payment")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/savePayment")
	public ResponseEntity<ResponseStructure<Payment>> savePayment(@RequestBody Payment payment) {
		return paymentService.savePayment(payment);	
	}
	@Operation(summary = "Fetch Payment By Id", description = "API is used to Fetch the Payment")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Payment fetched "),
			@ApiResponse(responseCode = "404", description = "Payment not found for the given id") })
	@GetMapping("/fetchPaymentById")
	public ResponseEntity<ResponseStructure<Payment>> fetchPaymentById(@RequestParam int paymentId){
		return paymentService.fetchPaymentById(paymentId);
	}
	@Operation(summary = "Fetch All Payments", description = "API is used to fetch all the Payments")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Payments fetched "),
			@ApiResponse(responseCode = "404", description = "no Owners found") })
	@GetMapping("/fetchAllPayment")
	public ResponseEntity<ResponseStructureList<Payment>> fetchAllPayment(){
		return paymentService.fetchAllPayment();
	}
	@Operation(summary = "Update Payment", description = "API is used to update the Payment")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Payment Upadted "),
			@ApiResponse(responseCode = "404", description = "Payment not found for the given id") })
	@PutMapping("/updatePaymentById")
	public ResponseEntity<ResponseStructure<Payment>> updatePaymentById(@RequestParam int oldPaymentId,@RequestBody Payment newPayment){
		return paymentService.updatePaymentById(oldPaymentId, newPayment);
	}
	@Operation(summary = "Delete Payment", description = "API is used to delete the Payment")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Payment deleted "),
			@ApiResponse(responseCode = "404", description = "Payment not found for the given id") })
	@DeleteMapping("/deletePaymentById")
	public ResponseEntity<ResponseStructure<Payment>> deletePaymentById(@RequestParam int paymentId){
		return paymentService.deletePaymentById(paymentId);
	}

}
