package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Owner;
import com.project.Springboot.service.OwnerService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class OwnerController {
	@Autowired
	OwnerService ownerService;
	
	@Operation(summary = "Save Owner", description = "API is used to save the Owner")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveOwner")
	public ResponseEntity<ResponseStructure<Owner>> saveOwner(@RequestBody Owner owner) {
		return ownerService.saveOwner(owner);	
	}
	@Operation(summary = "Fetch Owner By Id", description = "API is used to Fetch the Owner")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Owner fetched "),
			@ApiResponse(responseCode = "404", description = "Owner not found for the given id") })
	@GetMapping("/fetchOwnerById")
	public ResponseEntity<ResponseStructure<Owner>> fetchOwnerById(@RequestParam int ownerId){
		return ownerService.fetchOwnerById(ownerId);
	}
	@Operation(summary = "Fetch All Owners", description = "API is used to fetch all the Owners")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Movies fetched "),
			@ApiResponse(responseCode = "404", description = "no Owners found") })
	@GetMapping("/fetchAllOwner")
	public ResponseEntity<ResponseStructureList<Owner>> fetchAllOwner(){
		return ownerService.fetchAllOwner();
	}
	@Operation(summary = "Update Owner", description = "API is used to update the Owner")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Owner Upadted "),
			@ApiResponse(responseCode = "404", description = "Owner not found for the given id") })
	@PutMapping("/updateOwnerById")
	public ResponseEntity<ResponseStructure<Owner>> updateOwnerById(@RequestParam int oldOwnerId,@RequestBody Owner newOwner){
		return ownerService.updateOwnerById(oldOwnerId, newOwner);
	}
	@Operation(summary = "Delete Owner", description = "API is used to delete the Owner")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Owner deleted "),
			@ApiResponse(responseCode = "404", description = "OwnerOwner not found for the given id") })
	@DeleteMapping("/deleteOwnerById")
	public ResponseEntity<ResponseStructure<Owner>> deleteOwnerById(@RequestParam int ownerId){
		return ownerService.deleteOwnerById(ownerId);
	}
}
