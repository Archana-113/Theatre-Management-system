package com.project.Springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import com.project.Springboot.dto.Address;
import com.project.Springboot.service.AddressService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

@RestController
	public class AddressController {
		
		@Autowired
		AddressService addressService;
		
		@Operation(summary = "Save Address", description = "API is used to save the Address")
		@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
		@PostMapping("/saveAddress")
		public ResponseEntity<ResponseStructure<Address>> saveAddress(@RequestBody Address address) {
			return addressService.saveAddress(address);	
		}
		
		
		@Operation(summary = "Test Application", description = "API is used to test the Application")
		@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "application is running "),
				@ApiResponse(responseCode = "404", description = "application not running") })
		@GetMapping("/")
	    public String home() {
	        return "Spring Boot application is running!";
	    }
		
		@Operation(summary = "Fetch Address By Id", description = "API is used to Fetch the Address")
		@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Address fetched "),
				@ApiResponse(responseCode = "404", description = "Address not found for the given id") })
		@GetMapping("/fetchAddressById")
		public ResponseEntity<ResponseStructure<Address>> fetchAddressById(@RequestParam int addressId) {
			return addressService.fetchAddressById(addressId);
		}
		
		@Operation(summary = "Update Address", description = "API is used to update the Address")
		@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Address Upadted "),
				@ApiResponse(responseCode = "404", description = "Address not found for the given id") })
		@PutMapping("/updateAddressById")
		public ResponseEntity<ResponseStructure<Address>> updateAddressById(@RequestParam int oldAddress ,@RequestBody Address address) {
			return addressService.updateAddressById(oldAddress, address);
		}
		
		@Operation(summary = "Fetch All Addresses", description = "API is used to fetch all the Addresses")
		@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Addresses fetched "),
				@ApiResponse(responseCode = "404", description = "no Address found") })
		@GetMapping("/fetchAllAddress")
		public ResponseEntity<ResponseStructureList<Address>> fetchAllAddress() {
			return addressService.fetchAllAddress();
		}
		
		@Operation(summary = "Delete Address", description = "API is used to delete the Address")
		@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Address deleted "),
				@ApiResponse(responseCode = "404", description = "Address not found for the given id") })
		@DeleteMapping("/deleteAddressById")
		public ResponseEntity<ResponseStructure<Address>> deleteAddressById(int addressId) {
			return addressService.deleteAddressById(addressId);
		}

	}
