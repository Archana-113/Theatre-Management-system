package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Branch;
import com.project.Springboot.service.BranchService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class BranchController {
	@Autowired
	BranchService branchService;
	
	@Operation(summary = "Save Branch", description = "API is used to save the Branch")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveBranch")
	public ResponseEntity<ResponseStructure<Branch>> saveBranch(@RequestBody Branch branch) {
		return branchService.saveBranch(branch);	
	}
	@Operation(summary = "Fetch Branch By Id", description = "API is used to Fetch the Branch")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Branch fetched "),
			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@GetMapping("/fetchBranchById")
	public ResponseEntity<ResponseStructure<Branch>> fetchBranchById(@RequestParam int branchId){
		return branchService.fetchBranchById(branchId);
	}
	@Operation(summary = "Fetch All Branches", description = "API is used to fetch all the Branches")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Branches fetched "),
			@ApiResponse(responseCode = "404", description = "no Branch found") })
	@GetMapping("/fetchAllBranch")
	public ResponseEntity<ResponseStructureList<Branch>> fetchAllBranch(){
		return branchService.fetchAllBranch();
	}
	@Operation(summary = "Update Branch", description = "API is used to update the Branch")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Branch Upadted "),
			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@PutMapping("/updateBranchById")
	public ResponseEntity<ResponseStructure<Branch>> updateBranchById(@RequestParam int oldBranchId,@RequestBody Branch newBranch){
		return branchService.updateBranchById(oldBranchId, newBranch);
	}
	@Operation(summary = "Delete Branch", description = "API is used to delete the Branch")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Branch deleted "),
			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@DeleteMapping("/deleteBranchById")
	public ResponseEntity<ResponseStructure<Branch>> deleteBranchById(@RequestParam int branchId){
		return branchService.deleteBranchById(branchId);
	}
	

}
