package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Movie;
import com.project.Springboot.service.MovieService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class MovieController {
	@Autowired
	MovieService movieService;
	
	@Operation(summary = "Save Movie", description = "API is used to save the Movie")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveMovie")
	public ResponseEntity<ResponseStructure<Movie>> saveMovie(@RequestBody Movie movie) {
		return movieService.saveMovie(movie);	
	}
	@Operation(summary = "Fetch Movie By Id", description = "API is used to Fetch the Movie")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Movie fetched "),
			@ApiResponse(responseCode = "404", description = "Movie not found for the given id") })
	@GetMapping("/fetchMovieById")
	public ResponseEntity<ResponseStructure<Movie>> fetchMovieById(@RequestParam int movieId){
		return movieService.fetchMovieById(movieId);
	}
	@Operation(summary = "Fetch All Movies", description = "API is used to fetch all the Movies")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Movies fetched "),
			@ApiResponse(responseCode = "404", description = "no Movies found") })
	@GetMapping("/fetchAllMovie")
	public ResponseEntity<ResponseStructureList<Movie>> fetchAllMovie(){
		return movieService.fetchAllMovie();
	}
	@Operation(summary = "Update Movie", description = "API is used to update the Movie")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Movie Upadted "),
			@ApiResponse(responseCode = "404", description = "Movie not found for the given id") })
	@PutMapping("/updateMovieById")
	public ResponseEntity<ResponseStructure<Movie>> updateMovieById(@RequestParam int oldMovieId,@RequestBody Movie newMovie){
		return movieService.updateMovieById(oldMovieId, newMovie);
	}
	@Operation(summary = "Delete Movie", description = "API is used to delete the Movie")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Movie deleted "),
			@ApiResponse(responseCode = "404", description = "Movie not found for the given id") })
	@DeleteMapping("/deleteMovieById")
	public ResponseEntity<ResponseStructure<Movie>> deleteMovieById(@RequestParam int movieId){
		return movieService.deleteMovieById(movieId);
	}

}
