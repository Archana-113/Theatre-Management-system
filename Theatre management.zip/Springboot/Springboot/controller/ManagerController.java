package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Manager;
import com.project.Springboot.service.ManagerService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class ManagerController {
	@Autowired
	ManagerService managerService;
	
	@Operation(summary = "Save Manager", description = "API is used to save the Manager")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveManager")
	public ResponseEntity<ResponseStructure<Manager>> saveManager(@RequestBody Manager manager) {
		return managerService.saveManager(manager);	
	}
	@Operation(summary = "Fetch Manager By Id", description = "API is used to Fetch the Manager")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Manager fetched "),
			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@GetMapping("/fetchManagerById")
	public ResponseEntity<ResponseStructure<Manager>> fetchManagerById(@RequestParam int managerId){
		return managerService.fetchManagerById(managerId);
	}
	@Operation(summary = "Fetch All Managers", description = "API is used to fetch all the Managers")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Managers fetched "),
			@ApiResponse(responseCode = "404", description = "no Managers found") })
	@GetMapping("/fetchAllManager")
	public ResponseEntity<ResponseStructureList<Manager>> fetchAllManager(){
		return managerService.fetchAllManager();
	}
	@Operation(summary = "Update Manager", description = "API is used to update the Manager")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Manager Upadted "),
			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@PutMapping("/updateManagerById")
	public ResponseEntity<ResponseStructure<Manager>> updateManagerById(@RequestParam int oldManagerId,@RequestBody Manager newManager){
		return managerService.updateMangerById(oldManagerId, newManager);
	}
	@Operation(summary = "Delete Manager", description = "API is used to delete the Manager")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Manager deleted "),
			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@DeleteMapping("/deleteManagerById")
	public ResponseEntity<ResponseStructure<Manager>> deleteManagerById(@RequestParam int managerId){
		return managerService.deleteMangerById(managerId);
	}

}
