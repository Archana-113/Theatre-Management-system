package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.staff;
import com.project.Springboot.service.StaffService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class StaffController {
	@Autowired
	StaffService staffService;
	
	@Operation(summary = "Save Staff", description = "API is used to save the Staff")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveStaff")
	public ResponseEntity<ResponseStructure<staff>> saveStaff(@RequestBody staff staffObj) {
		return staffService.saveStaff(staffObj);	
	}
	@Operation(summary = "Fetch Staff By Id", description = "API is used to Fetch the Staff")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Staff fetched "),
			@ApiResponse(responseCode = "404", description = "Staff not found for the given id") })
	@GetMapping("/fetchStaffById")
	public ResponseEntity<ResponseStructure<staff>> fetchScreenById(@RequestParam int staffId){
		return staffService.fetchStaffById(staffId);
	}
	@Operation(summary = "Fetch All Staffs", description = "API is used to fetch all the Staffs")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Staffs fetched "),
			@ApiResponse(responseCode = "404", description = "no Staffs found") })
	@GetMapping("/fetchAllStaff")
	public ResponseEntity<ResponseStructureList<staff>> fetchAllStaff(){
		return staffService.fetchAllStaff();
	}
	@Operation(summary = "Update Staff", description = "API is used to update the Staff")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Staff Upadted "),
			@ApiResponse(responseCode = "404", description = "Staff not found for the given id") })
	@PutMapping("/updateStaffById")
	public ResponseEntity<ResponseStructure<staff>> updateStaffById(@RequestParam int oldStaffId,@RequestBody staff newStaff){
		return staffService.updateStaffById(oldStaffId, newStaff);
	}
	@Operation(summary = "Delete Staff", description = "API is used to delete the Staff")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Staff deleted "),
			@ApiResponse(responseCode = "404", description = "Staff not found for the given id") })
	@DeleteMapping("/deleteStaffById")
	public ResponseEntity<ResponseStructure<staff>> deleteStaffById(@RequestParam int staffId){
		return staffService.deleteStaffById(staffId);
	}

}
