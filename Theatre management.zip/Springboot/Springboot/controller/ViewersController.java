package com.project.Springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Springboot.dto.Viewers;
import com.project.Springboot.service.ViewersService;
import com.project.Springboot.util.ResponseStructure;
import com.project.Springboot.util.ResponseStructureList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class ViewersController {
	@Autowired
	ViewersService viewersService;
	
	@Operation(summary = "Save Viewers", description = "API is used to save the Viewers")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created")})
	@PostMapping("/saveViewers")
	public ResponseEntity<ResponseStructure<Viewers>> saveViewers(@RequestBody Viewers viewers) {
		return viewersService.saveViewers(viewers);	
	}
	@Operation(summary = "Fetch Viewers By Id", description = "API is used to Fetch the Viewers")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully Viewers fetched "),
			@ApiResponse(responseCode = "404", description = "Viewers not found for the given id") })
	@GetMapping("/fetchViewersById")
	public ResponseEntity<ResponseStructure<Viewers>> fetchViewersById(@RequestParam int viewersId){
		return viewersService.fetchViewersById(viewersId);
	}
	@Operation(summary = "Fetch All Viewers", description = "API is used to fetch all the Viewers")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully all Viewers fetched "),
			@ApiResponse(responseCode = "404", description = "no Viewers found") })
	@GetMapping("/fetchAllViewers")
	public ResponseEntity<ResponseStructureList<Viewers>> fetchAllViewers(){
		return viewersService.fetchAllViewers();
	}
	@Operation(summary = "Update Viewers", description = "API is used to update the Viewers")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Viewers Upadted "),
			@ApiResponse(responseCode = "404", description = "Viewers not found for the given id") })
	@PutMapping("/updateViewersById")
	public ResponseEntity<ResponseStructure<Viewers>> updateViewersById(@RequestParam int oldViewersId,@RequestBody Viewers newViewers){
		return viewersService.updateViewersById(oldViewersId, newViewers);
	}
	@Operation(summary = "Delete Viewers", description = "API is used to delete the Viewers")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Viewers deleted "),
			@ApiResponse(responseCode = "404", description = "Viewers not found for the given id") })
	@DeleteMapping("/deleteViewersById")
	public ResponseEntity<ResponseStructure<Viewers>> deleteViewersById(@RequestParam int viewersId){
		return viewersService.deleteViewersById(viewersId);
	}

}
