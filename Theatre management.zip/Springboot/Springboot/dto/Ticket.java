package com.project.Springboot.dto;

import java.sql.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ticketId;
	private String ticketType;
	private double ticketPrice;
	private String ticketStatus;
	private Date ticketBookingDate;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Payment payment;
	
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getTicktType() {
		return ticketType;
	}
	public void setTicktType(String ticketType) {
		this.ticketType = ticketType;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public String getTicketStatus() {
		return ticketStatus;
	}
	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}
	public Date getTicketBookingDate() {
		return ticketBookingDate;
	}
	public void setTicketBookingDate(Date ticketBookingDate) {
		this.ticketBookingDate = ticketBookingDate;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	
	
	

}
