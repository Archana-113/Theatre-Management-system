package com.project.Springboot.dto;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Viewers {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int viewerId;
	private String viewerName;
	private long viewerPhone;
	private String viewerGender;
	private String viewerAge;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Food> food;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Ticket ticket;

	public int getViewerId() {
		return viewerId;
	}

	public void setViewerId(int viewerId) {
		this.viewerId = viewerId;
	}

	public String getViewerName() {
		return viewerName;
	}

	public void setViewerName(String viewerName) {
		this.viewerName = viewerName;
	}

	public long getViewerPhone() {
		return viewerPhone;
	}

	public void setViewerPhone(long viewerPhone) {
		this.viewerPhone = viewerPhone;
	}

	public String getViewerGender() {
		return viewerGender;
	}

	public void setViewerGender(String viewerGender) {
		this.viewerGender = viewerGender;
	}

	public String getViewerAge() {
		return viewerAge;
	}

	public void setViewerAge(String viewerAge) {
		this.viewerAge = viewerAge;
	}

	public List<Food> getFood() {
		return food;
	}

	public void setFood(List<Food> food) {
		this.food = food;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
}
