package com.project.Springboot.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Manager {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int managerId;
	private String managerName;
	private String managerSalary;
	private String managerEmail;
	private long managerPhone;
	
	public void setMangerId(int managerId) {
		this.managerId = managerId;
	}
	public int getMangerId(int managerId) {
		return managerId;
	}
	public void setMangerName(String managerName) {
		this.setManagerName(managerName);
	}
    public String getManagerName(String managerName) {
    	return managerName;
    }
	public String getManagerSalary() {
		return managerSalary;
	}
	public void setManagerSalary(String managerSalary) {
		this.managerSalary = managerSalary;
	}
	public String getManagerEmail() {
		return managerEmail;
	}
	public void setManagerEmail(String managerEmail) {
		this.managerEmail = managerEmail;
	}
	public long getManagerPhone() {
		return managerPhone;
	}
	public void setManagerPhone(long managerPhone) {
		this.managerPhone = managerPhone;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
    
}
