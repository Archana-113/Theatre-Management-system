package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Review;

public interface ReviewRepo extends JpaRepository<Review, Integer>  {

}
