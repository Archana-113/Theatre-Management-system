package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Address;


public interface AddressRepo extends JpaRepository<Address, Integer>{

}
