package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Movie;

public interface MovieRepo extends JpaRepository<Movie, Integer>  {

}
