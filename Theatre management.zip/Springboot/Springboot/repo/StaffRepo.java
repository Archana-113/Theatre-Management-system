package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.staff;

public interface StaffRepo extends JpaRepository<staff, Integer>  {

}
