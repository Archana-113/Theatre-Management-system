package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Owner;

public interface OwnerRepo extends JpaRepository<Owner, Integer> {

}
