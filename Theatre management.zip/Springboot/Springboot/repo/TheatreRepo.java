package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Theatre;

public interface TheatreRepo extends JpaRepository<Theatre, Integer> {

}
