package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Seat;

public interface SeatRepo extends JpaRepository<Seat, Integer> {

}
