package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Payment;

public interface PaymentRepo extends JpaRepository<Payment, Integer> {

}
