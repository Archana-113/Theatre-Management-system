package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Manager;



public interface ManagerRepo extends JpaRepository<Manager, Integer> {

}
