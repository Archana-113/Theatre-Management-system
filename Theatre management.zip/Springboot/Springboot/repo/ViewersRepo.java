package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Viewers;

public interface ViewersRepo extends JpaRepository<Viewers, Integer>  {

}
