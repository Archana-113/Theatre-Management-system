package com.project.Springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Springboot.dto.Ticket;

public interface TicketRepo extends JpaRepository<Ticket, Integer>  {

}
