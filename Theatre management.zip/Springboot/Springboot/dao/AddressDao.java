package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Address;
import com.project.Springboot.repo.AddressRepo;


@Repository
public class AddressDao {
	@Autowired
	AddressRepo addressRepo;
	
	public Address saveAddress(Address address) {
		return addressRepo.save(address);
		
	}
	public Address fetchAddressById(int addressId) {
		Optional<Address> dbAddress= addressRepo.findById(addressId);
		if(dbAddress.isPresent())
		{
			return dbAddress.get();
		}
		else
		{
			return null;
		}
	}
	public List<Address> findAllAddress(){
		return addressRepo.findAll();
	}
	public Address updateAddressById(int oldAddressId,Address newAddress) {
		newAddress.setAddressId(oldAddressId);
		return saveAddress(newAddress);
	}
	public Address deleteAddressById(int addressId) {
		Address address = fetchAddressById(addressId);
		addressRepo.delete(address);
		return address;
		
	}


}
