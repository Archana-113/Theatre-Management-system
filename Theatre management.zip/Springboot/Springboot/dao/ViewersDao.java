package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Viewers;
import com.project.Springboot.repo.ViewersRepo;

@Repository
public class ViewersDao {
	
	@Autowired
	ViewersRepo viewersRepo;
	
	public Viewers saveViewers(Viewers viewers) {
		return viewersRepo.save(viewers);
	}
	public Viewers fetchViewersById(int viewersId) {
		Optional<Viewers> dbViewer = viewersRepo.findById(viewersId);
		if(dbViewer.isPresent()) {
			return dbViewer.get();
		}
		else {
			return null;
		}
	}
	public List<Viewers> fetchAllViewers(){
		return viewersRepo.findAll();
	}
	public Viewers updateViewersById(int oldViewerId,Viewers newViewers) {
		newViewers.setViewerId(oldViewerId);
		return saveViewers(newViewers);
	}
	public Viewers deleteViewersById(int viewerId) {
		Viewers viewers = fetchViewersById(viewerId);
		viewersRepo.delete(viewers);
		return viewers;
	}

}
