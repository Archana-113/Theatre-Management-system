package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Food;
import com.project.Springboot.repo.FoodRepo;

@Repository
public class FoodDao {
	
	@Autowired
	FoodRepo foodRepo;
	
	public Food saveFood(Food food) {
		return foodRepo.save(food);	
	}
	public Food fetchFoodById(int foodId) {
		Optional<Food> dbFood = foodRepo.findById(foodId);
		if(dbFood.isPresent()) {
			return dbFood.get();
		}else {
			return null;
		}
	}
	public List<Food> fetchAllFood(){
		List<Food> foodList = foodRepo.findAll();
		return foodList;
	}
	public Food updateFoodById(int oldFoodId , Food newFood) {
		newFood.setFoodId(oldFoodId);
		return saveFood(newFood);
	}
	public Food deleteFoodById(int foodId) {
		Food food = fetchFoodById(foodId);
		foodRepo.delete(food);
		return food;
	}

}
