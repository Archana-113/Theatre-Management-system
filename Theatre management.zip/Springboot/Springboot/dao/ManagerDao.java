package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Manager;
import com.project.Springboot.repo.ManagerRepo;

@Repository
public class ManagerDao {
	
	@Autowired
	ManagerRepo managerRepo;
	
	public Manager saveManager(Manager manager) {
		return managerRepo.save(manager);	
	}
	public Manager fetchManagerById(int managerId) {
		Optional<Manager> dbManager = managerRepo.findById(managerId);
		if(dbManager.isPresent()) {
			return dbManager.get();
		}else {
			return null;
		}	
	}
	public List<Manager> fetchAllManager(){
		List<Manager> managerList = managerRepo.findAll();
		return managerList;
	}
	public Manager updateManagerById(int oldManager, Manager newManager) {
		newManager.setMangerId(oldManager);
		return saveManager(newManager);
	}
	public Manager deleteManagerById(int managerId) {
		Manager manager = fetchManagerById(managerId);
		managerRepo.delete(manager);
		return manager;
	}
	

}
