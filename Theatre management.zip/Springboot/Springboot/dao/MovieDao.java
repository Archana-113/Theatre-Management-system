package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Movie;
import com.project.Springboot.repo.MovieRepo;

@Repository
public class MovieDao {
	
	@Autowired
	MovieRepo movieRepo;
	
	public Movie saveMovie(Movie movie) {
		return movieRepo.save(movie);
	}
	public Movie fetchMovieById(int movieId) {
		Optional<Movie> dbMovie = movieRepo.findById(movieId);
		if(dbMovie.isPresent()) {
			return dbMovie.get();
		}else {
			return null;
		}
	}
	public List<Movie> fetchAllMovie(){
		//List<Movie> movieList= movieRepo.findAll();
		return movieRepo.findAll();
	}
	public Movie updateMovieById(int oldMovieId, Movie newMovie) {
		newMovie.setMovieId(oldMovieId);
		return saveMovie(newMovie);
	}
	public Movie deleteMovieById(int movieId) {
		Movie movie = fetchMovieById(movieId);
		movieRepo.delete(movie);
		return movie;
	}
	

}
