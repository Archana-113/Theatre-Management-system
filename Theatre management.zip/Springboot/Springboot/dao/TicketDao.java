package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Ticket;
import com.project.Springboot.repo.TicketRepo;


@Repository
public class TicketDao {
	
	@Autowired
	TicketRepo ticketRepo;
	
	public Ticket saveTicket(Ticket ticket) {
		return ticketRepo.save(ticket);	
	}
	public Ticket fetchTicketById(int ticketId) {
		Optional<Ticket> dbTicket = ticketRepo.findById(ticketId);
		if(dbTicket.isPresent()) {
			return dbTicket.get();
		}else {
			return null;
		}
	}
	public List<Ticket> fetchAllTicket(){
		return ticketRepo.findAll();
	}
	public Ticket updateTicketById(int oldTicketId,Ticket newTicket) {
		newTicket.setTicketId(oldTicketId);
		return saveTicket(newTicket);
	}
	public Ticket deleteTicketById(int ticketId) {
		Ticket ticket = fetchTicketById(ticketId);
		ticketRepo.delete(ticket);
		return ticket;
	}

}
