package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Review;
import com.project.Springboot.repo.ReviewRepo;

@Repository
public class ReviewDao {
	
	@Autowired
	ReviewRepo reviewRepo;
	
	public Review saveReview(Review review) {
		return reviewRepo.save(review);
	}
	public Review fetchReviewById(int reviewId) {
		Optional<Review> dbReview = reviewRepo.findById(reviewId);
		if(dbReview.isPresent()) {
			return dbReview.get();
		}else {
			return null;
		}
	}
	public List<Review> fetchAllReview() {
		return reviewRepo.findAll();
	}
	public Review updateReviewById(int reviewId , Review newReview) {
		newReview.setReviewId(reviewId);
		return saveReview(newReview);
	}
   public Review deleteReviewById(int reviewId) {
	   Review review = fetchReviewById(reviewId);
	   reviewRepo.delete(review);
	   return review;
   }
}
