package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Payment;
import com.project.Springboot.repo.PaymentRepo;

@Repository
public class PaymentDao {
	
	@Autowired
	PaymentRepo paymentRepo;
	
	public Payment savePayment(Payment payment) {
		return paymentRepo.save(payment);
	}
	public Payment fetchPaymentById(int paymentId) {
		Optional<Payment> dbPayment = paymentRepo.findById(paymentId);
		if(dbPayment.isPresent()) {
			return dbPayment.get();
		}
		else {
			return null;
		}
	}
	public List<Payment> fetchAllPayment(){
		return paymentRepo.findAll();
	}
	public Payment updatePaymentById(int paymentId,Payment newPayment) {
		newPayment.setPaymentId(paymentId);
		return savePayment(newPayment);
	}
	public Payment deletePaymentById(int paymentId) {
		Payment payment = fetchPaymentById(paymentId);
		paymentRepo.delete(payment);
		return payment;
	}

}
