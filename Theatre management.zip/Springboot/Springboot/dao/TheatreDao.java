package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Theatre;
import com.project.Springboot.repo.TheatreRepo;



@Repository
public class TheatreDao {
	
	@Autowired
	TheatreRepo theatreRepo;
	
	public Theatre saveTheatre(Theatre theatre) {
		return theatreRepo.save(theatre);
	}
	public Theatre fetchTheatreById(int theatreId) {
		Optional<Theatre> dbTheatre = theatreRepo.findById(theatreId);
		if(dbTheatre.isPresent()) {
			return dbTheatre.get();
		}else {
			return null;
		}
	}
	public List<Theatre> fetchAllTheatre(){
		return theatreRepo.findAll();
	}
	public Theatre updateTheatreById(int oldTheatreId,Theatre newTheatre) {
		newTheatre.setTheatreId(oldTheatreId);
		return saveTheatre(newTheatre);
	}
	public Theatre deleteTheatreById(int theatreId) {
		Theatre theatre = fetchTheatreById(theatreId);
		theatreRepo.delete(theatre);
		return theatre;
	}
	

}
