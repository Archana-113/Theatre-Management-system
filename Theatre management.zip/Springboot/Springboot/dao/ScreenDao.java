package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Screen;
import com.project.Springboot.repo.ScreenRepo;

@Repository 
public class ScreenDao {
	
	@Autowired
	ScreenRepo screenRepo;
	
	public Screen saveScreen(Screen screen) {
		return screenRepo.save(screen);
	}
	public Screen fetchScreenById(int screenId) {
		Optional<Screen> dbScreen = screenRepo.findById(screenId);
		if(dbScreen.isPresent()) {
			return dbScreen.get();
		}
		else {
			return null;
		}
	}
	public List<Screen> fetchAllScreen(){
		return screenRepo.findAll();
	}
	public Screen updateScreenById(int oldScreenId,Screen newScreen) {
		newScreen.setScreenId(oldScreenId);
		return saveScreen(newScreen);
	}
	public Screen deleteScreenById(int screenId) {
		Screen screen = fetchScreenById(screenId);
		screenRepo.delete(screen);
		return screen;
	}
	

}
