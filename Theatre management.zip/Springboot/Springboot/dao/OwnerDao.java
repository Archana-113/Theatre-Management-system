package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Owner;
import com.project.Springboot.repo.OwnerRepo;

@Repository
public class OwnerDao {
	
	@Autowired
	OwnerRepo ownerRepo;
	
	public Owner saveOwner(Owner owner) {
		return ownerRepo.save(owner);
	}
	public Owner fetchOwnerById(int ownerId) {
		Optional<Owner> dbOwner = ownerRepo.findById(ownerId);
		if(dbOwner.isPresent()) {
			return dbOwner.get();
		}else {
			return null;
		}
	}
	public List<Owner> fetchAllOwner(){
		return ownerRepo.findAll();
	}
	public Owner updateOwnerById(int ownerId,Owner newOwner) {
		newOwner.setOwnerId(ownerId);
		return saveOwner(newOwner);
	}
	public Owner deleteOwnerById(int ownerId) {
		Owner owner = fetchOwnerById(ownerId);
		ownerRepo.delete(owner);
		return owner;
	}

}
