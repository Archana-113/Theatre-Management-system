package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.staff;
import com.project.Springboot.repo.StaffRepo;


@Repository
public class StaffDao {
	
	@Autowired
	StaffRepo staffRepo;
	
	public staff saveStaff(staff staffObj) {
		return staffRepo.save(staffObj);
	}
	public staff fetchStaffById(int staffId) {
		Optional<staff> dbStaff = staffRepo.findById(staffId);
		if(dbStaff.isPresent()) {
			return dbStaff.get();
		}else {
			return null;
		}	
	}
	public List<staff> fetchAllStaff(){
		return staffRepo.findAll();
	}
	public staff updateStaffById(int staffId,staff newStaff) {
		newStaff.setStaffId(staffId);
		return saveStaff(newStaff);
	}
	public staff deleteStaffById(int staffId) {
		staff staffObj = fetchStaffById(staffId);
		staffRepo.delete(staffObj);
		return staffObj;
	}

}
