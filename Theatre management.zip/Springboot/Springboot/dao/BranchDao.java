package com.project.Springboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Springboot.dto.Branch;
import com.project.Springboot.repo.BranchRepo;

@Repository
public class BranchDao {
	
	@Autowired
	BranchRepo branchRepo;
	
	public Branch saveBranch(Branch branch) {
		return branchRepo.save(branch);
	}
	
	public Branch fetchBranchById(int branchId) {
		Optional<Branch> dbBranch = branchRepo.findById(branchId);
		if(dbBranch.isPresent()) {
			return dbBranch.get();
		}else {
			return null;
		}
	}
	public List<Branch> fetchAllBranch(){
		return branchRepo.findAll();
		
	}
	public Branch updateBranchById(int oldbranchId , Branch newBranch) {
		newBranch.setBranchId(oldbranchId);
		return saveBranch(newBranch);
		
	}
	public Branch deleteBranchById(int branchId) {
		Branch branch = fetchBranchById(branchId);
		branchRepo.delete(branch);
		return branch;
	}

}
